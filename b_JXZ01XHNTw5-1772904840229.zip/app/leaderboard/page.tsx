'use client';

import { Trophy, Medal, Crown, Coins } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useGameStore } from '@/lib/store';
import { getTranslation } from '@/lib/i18n';
import { cn } from '@/lib/utils';

// Mock leaderboard data
const mockLeaderboard = [
  { id: '1', name: 'ProGamer2000', avatar: '', totalWins: 125000, totalOpened: 450 },
  { id: '2', name: 'SkinMaster', avatar: '', totalWins: 98500, totalOpened: 380 },
  { id: '3', name: 'LuckyShot', avatar: '', totalWins: 87200, totalOpened: 320 },
  { id: '4', name: 'CaseKing', avatar: '', totalWins: 76400, totalOpened: 290 },
  { id: '5', name: 'VirtualRich', avatar: '', totalWins: 65800, totalOpened: 255 },
  { id: '6', name: 'DragonLore', avatar: '', totalWins: 54300, totalOpened: 210 },
  { id: '7', name: 'AWPMaster', avatar: '', totalWins: 43200, totalOpened: 185 },
  { id: '8', name: 'SkinCollector', avatar: '', totalWins: 32100, totalOpened: 150 },
  { id: '9', name: 'CasePro', avatar: '', totalWins: 21500, totalOpened: 120 },
  { id: '10', name: 'Newbie123', avatar: '', totalWins: 15000, totalOpened: 80 },
];

export default function LeaderboardPage() {
  const { user, locale } = useGameStore();
  const t = (key: Parameters<typeof getTranslation>[1]) => getTranslation(locale, key);

  // Add current user to leaderboard if not already there
  const leaderboard = [...mockLeaderboard];
  if (user && !leaderboard.find(p => p.id === user.id)) {
    leaderboard.push({
      id: user.id,
      name: user.name,
      avatar: user.avatar,
      totalWins: user.totalWins,
      totalOpened: user.totalOpened,
    });
  }

  // Sort by total wins
  leaderboard.sort((a, b) => b.totalWins - a.totalWins);

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Crown className="h-6 w-6 text-[oklch(0.75_0.2_50)]" />;
      case 2:
        return <Medal className="h-6 w-6 text-[oklch(0.7_0.05_240)]" />;
      case 3:
        return <Medal className="h-6 w-6 text-[oklch(0.65_0.12_50)]" />;
      default:
        return <span className="text-sm font-bold text-muted-foreground">{rank}</span>;
    }
  };

  const getRankBg = (rank: number) => {
    switch (rank) {
      case 1:
        return 'bg-gradient-to-r from-[oklch(0.75_0.2_50/0.2)] to-transparent border-[oklch(0.75_0.2_50/0.5)]';
      case 2:
        return 'bg-gradient-to-r from-[oklch(0.7_0.05_240/0.15)] to-transparent border-[oklch(0.7_0.05_240/0.3)]';
      case 3:
        return 'bg-gradient-to-r from-[oklch(0.65_0.12_50/0.15)] to-transparent border-[oklch(0.65_0.12_50/0.3)]';
      default:
        return 'bg-card border-border';
    }
  };

  return (
    <div className="flex flex-col gap-6 p-4">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-2xl font-bold text-foreground">{t('topPlayers')}</h1>
        <p className="text-sm text-muted-foreground">
          Ranked by total winnings
        </p>
      </div>

      {/* Top 3 podium */}
      <div className="flex items-end justify-center gap-2">
        {/* 2nd place */}
        <div className="flex flex-col items-center">
          <Avatar className="h-14 w-14 border-2 border-[oklch(0.7_0.05_240)]">
            <AvatarFallback className="bg-[oklch(0.7_0.05_240/0.2)] text-sm">
              {leaderboard[1]?.name?.charAt(0) || '2'}
            </AvatarFallback>
          </Avatar>
          <div className="mt-2 flex h-20 w-20 flex-col items-center justify-center rounded-t-xl bg-[oklch(0.7_0.05_240/0.2)]">
            <span className="text-lg font-bold">2</span>
            <span className="text-xs text-muted-foreground">{leaderboard[1]?.totalWins}</span>
          </div>
        </div>

        {/* 1st place */}
        <div className="flex flex-col items-center">
          <Crown className="mb-1 h-6 w-6 text-[oklch(0.75_0.2_50)]" />
          <Avatar className="h-16 w-16 border-2 border-[oklch(0.75_0.2_50)]">
            <AvatarFallback className="bg-[oklch(0.75_0.2_50/0.2)] text-base">
              {leaderboard[0]?.name?.charAt(0) || '1'}
            </AvatarFallback>
          </Avatar>
          <div className="mt-2 flex h-28 w-24 flex-col items-center justify-center rounded-t-xl bg-[oklch(0.75_0.2_50/0.2)]">
            <span className="text-xl font-bold">1</span>
            <span className="text-sm font-semibold text-[oklch(0.75_0.2_50)]">{leaderboard[0]?.totalWins}</span>
          </div>
        </div>

        {/* 3rd place */}
        <div className="flex flex-col items-center">
          <Avatar className="h-12 w-12 border-2 border-[oklch(0.65_0.12_50)]">
            <AvatarFallback className="bg-[oklch(0.65_0.12_50/0.2)] text-xs">
              {leaderboard[2]?.name?.charAt(0) || '3'}
            </AvatarFallback>
          </Avatar>
          <div className="mt-2 flex h-16 w-16 flex-col items-center justify-center rounded-t-xl bg-[oklch(0.65_0.12_50/0.2)]">
            <span className="text-base font-bold">3</span>
            <span className="text-xs text-muted-foreground">{leaderboard[2]?.totalWins}</span>
          </div>
        </div>
      </div>

      {/* Full leaderboard */}
      <div className="space-y-2">
        {leaderboard.map((player, index) => {
          const rank = index + 1;
          const isCurrentUser = player.id === user?.id;
          
          return (
            <div
              key={player.id}
              className={cn(
                'flex items-center gap-3 rounded-xl border p-3 transition-all',
                getRankBg(rank),
                isCurrentUser && 'ring-2 ring-primary ring-offset-2 ring-offset-background'
              )}
            >
              {/* Rank */}
              <div className="flex h-8 w-8 items-center justify-center">
                {getRankIcon(rank)}
              </div>

              {/* Avatar */}
              <Avatar className="h-10 w-10">
                <AvatarImage src={player.avatar} />
                <AvatarFallback className="bg-secondary text-sm">
                  {player.name.charAt(0)}
                </AvatarFallback>
              </Avatar>

              {/* Name */}
              <div className="flex-1">
                <p className={cn(
                  'text-sm font-medium',
                  isCurrentUser && 'text-primary'
                )}>
                  {player.name}
                  {isCurrentUser && ' (You)'}
                </p>
                <p className="text-xs text-muted-foreground">
                  {player.totalOpened} cases opened
                </p>
              </div>

              {/* Winnings */}
              <div className="flex items-center gap-1 text-accent">
                <Coins className="h-4 w-4" />
                <span className="font-semibold">{player.totalWins.toLocaleString()}</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
