'use client';

import { use } from 'react';
import Link from 'next/link';
import { ArrowLeft } from 'lucide-react';
import { CaseSpinner } from '@/components/case-spinner';
import { useGameStore } from '@/lib/store';
import { getTranslation } from '@/lib/i18n';

interface CaseDetailPageProps {
  params: Promise<{ id: string }>;
}

export default function CaseDetailPage({ params }: CaseDetailPageProps) {
  const { id } = use(params);
  const { locale, cases } = useGameStore();
  const t = (key: Parameters<typeof getTranslation>[1]) => getTranslation(locale, key);

  const caseData = cases.find(c => c.id === id);

  if (!caseData) {
    return (
      <div className="flex flex-col items-center justify-center gap-4 p-8">
        <p className="text-muted-foreground">Case not found</p>
        <Link href="/cases" className="text-primary hover:underline">
          Back to cases
        </Link>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-6 p-4">
      {/* Header */}
      <div className="flex items-center gap-3">
        <Link
          href="/cases"
          className="flex h-10 w-10 items-center justify-center rounded-xl border border-border bg-card transition-colors hover:bg-secondary"
        >
          <ArrowLeft className="h-5 w-5" />
        </Link>
        <div>
          <h1 className="text-xl font-bold text-foreground">{caseData.name}</h1>
          <p className="text-sm text-muted-foreground">
            {caseData.items.length} possible items
          </p>
        </div>
      </div>

      {/* Case spinner */}
      <CaseSpinner caseData={caseData} />
    </div>
  );
}
