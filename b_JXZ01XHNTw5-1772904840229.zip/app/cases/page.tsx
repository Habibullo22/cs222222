'use client';

import { CaseCard } from '@/components/case-card';
import { useGameStore } from '@/lib/store';
import { getTranslation } from '@/lib/i18n';

export default function CasesPage() {
  const { locale, cases } = useGameStore();
  const t = (key: Parameters<typeof getTranslation>[1]) => getTranslation(locale, key);

  return (
    <div className="flex flex-col gap-6 p-4">
      <div>
        <h1 className="text-2xl font-bold text-foreground">{t('cases')}</h1>
        <p className="text-sm text-muted-foreground">
          Choose a case to open and win virtual items
        </p>
      </div>

      <div className="grid grid-cols-2 gap-3">
        {cases.map((caseData) => (
          <CaseCard key={caseData.id} caseData={caseData} />
        ))}
      </div>
    </div>
  );
}
