'use client';

import { useState } from 'react';
import { redirect } from 'next/navigation';
import { 
  Shield, 
  Box, 
  Users, 
  Ticket, 
  BarChart3, 
  Plus, 
  Trash2, 
  Edit2,
  Coins,
  Package,
  TrendingUp
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useGameStore } from '@/lib/store';
import { getTranslation } from '@/lib/i18n';
import { cn } from '@/lib/utils';
import type { Rarity, Condition } from '@/lib/store';

export default function AdminPage() {
  const { 
    user, 
    locale, 
    cases, 
    promoCodes, 
    allUsers,
    createPromoCode,
    deletePromoCode,
    addCase,
    deleteCase,
    addItem,
  } = useGameStore();
  const t = (key: Parameters<typeof getTranslation>[1]) => getTranslation(locale, key);

  // Redirect if not admin
  if (!user?.isAdmin) {
    redirect('/');
  }

  const [showPromoDialog, setShowPromoDialog] = useState(false);
  const [showCaseDialog, setShowCaseDialog] = useState(false);
  const [showItemDialog, setShowItemDialog] = useState(false);
  const [selectedCaseId, setSelectedCaseId] = useState<string | null>(null);

  // Form states
  const [promoCode, setPromoCode] = useState('');
  const [promoValue, setPromoValue] = useState('');
  const [promoMaxUses, setPromoMaxUses] = useState('');

  const [caseName, setCaseName] = useState('');
  const [casePrice, setCasePrice] = useState('');

  const [itemName, setItemName] = useState('');
  const [itemPrice, setItemPrice] = useState('');
  const [itemRarity, setItemRarity] = useState<Rarity>('common');
  const [itemCondition, setItemCondition] = useState<Condition>('fieldTested');

  // Stats
  const totalUsers = allUsers.length;
  const totalCasesOpened = allUsers.reduce((sum, u) => sum + u.totalOpened, 0);
  const totalCoinsSpent = totalCasesOpened * 500; // Approximate

  const handleCreatePromo = () => {
    if (!promoCode || !promoValue || !promoMaxUses) return;
    createPromoCode(promoCode, parseInt(promoValue), parseInt(promoMaxUses));
    setPromoCode('');
    setPromoValue('');
    setPromoMaxUses('');
    setShowPromoDialog(false);
  };

  const handleCreateCase = () => {
    if (!caseName || !casePrice) return;
    addCase({
      name: caseName,
      image: '/cases/new.jpg',
      price: parseInt(casePrice),
      items: [],
    });
    setCaseName('');
    setCasePrice('');
    setShowCaseDialog(false);
  };

  const handleAddItem = () => {
    if (!selectedCaseId || !itemName || !itemPrice) return;
    addItem(selectedCaseId, {
      name: itemName,
      image: '/items/new.jpg',
      price: parseInt(itemPrice),
      rarity: itemRarity,
      condition: itemCondition,
    });
    setItemName('');
    setItemPrice('');
    setItemRarity('common');
    setItemCondition('fieldTested');
    setShowItemDialog(false);
    setSelectedCaseId(null);
  };

  return (
    <div className="flex flex-col gap-6 p-4">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-destructive/20">
          <Shield className="h-6 w-6 text-destructive" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-foreground">{t('adminPanel')}</h1>
          <p className="text-sm text-muted-foreground">
            Manage your platform
          </p>
        </div>
      </div>

      {/* Stats overview */}
      <div className="grid grid-cols-2 gap-3">
        <div className="rounded-xl border border-border bg-card p-4">
          <div className="flex items-center gap-2 mb-2">
            <Users className="h-4 w-4 text-primary" />
            <span className="text-xs text-muted-foreground">{t('totalUsers')}</span>
          </div>
          <p className="text-2xl font-bold text-foreground">{totalUsers}</p>
        </div>
        <div className="rounded-xl border border-border bg-card p-4">
          <div className="flex items-center gap-2 mb-2">
            <Box className="h-4 w-4 text-accent" />
            <span className="text-xs text-muted-foreground">{t('totalCasesOpened')}</span>
          </div>
          <p className="text-2xl font-bold text-accent">{totalCasesOpened}</p>
        </div>
        <div className="rounded-xl border border-border bg-card p-4">
          <div className="flex items-center gap-2 mb-2">
            <Coins className="h-4 w-4 text-accent" />
            <span className="text-xs text-muted-foreground">{t('totalCoinsSpent')}</span>
          </div>
          <p className="text-2xl font-bold text-foreground">{totalCoinsSpent.toLocaleString()}</p>
        </div>
        <div className="rounded-xl border border-border bg-card p-4">
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="h-4 w-4 text-primary" />
            <span className="text-xs text-muted-foreground">{t('activeUsers')}</span>
          </div>
          <p className="text-2xl font-bold text-primary">{Math.ceil(totalUsers * 0.7)}</p>
        </div>
      </div>

      {/* Admin tabs */}
      <Tabs defaultValue="cases" className="w-full">
        <TabsList className="w-full">
          <TabsTrigger value="cases" className="flex-1">
            <Box className="mr-2 h-4 w-4" />
            {t('manageCases')}
          </TabsTrigger>
          <TabsTrigger value="promos" className="flex-1">
            <Ticket className="mr-2 h-4 w-4" />
            {t('promoCodes')}
          </TabsTrigger>
        </TabsList>

        {/* Cases tab */}
        <TabsContent value="cases" className="mt-4 space-y-4">
          <Button onClick={() => setShowCaseDialog(true)} className="w-full">
            <Plus className="mr-2 h-4 w-4" />
            Add New Case
          </Button>

          <div className="space-y-3">
            {cases.map((caseData) => (
              <div
                key={caseData.id}
                className="rounded-xl border border-border bg-card p-4"
              >
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <h3 className="font-semibold text-foreground">{caseData.name}</h3>
                    <p className="text-sm text-muted-foreground">
                      {caseData.price} coins - {caseData.items.length} items
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        setSelectedCaseId(caseData.id);
                        setShowItemDialog(true);
                      }}
                    >
                      <Plus className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => deleteCase(caseData.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                {/* Items in case */}
                {caseData.items.length > 0 && (
                  <div className="flex flex-wrap gap-1">
                    {caseData.items.map((item) => (
                      <span
                        key={item.id}
                        className={cn(
                          'rounded-full px-2 py-0.5 text-[10px] font-medium',
                          item.rarity === 'legendary' && 'bg-[oklch(0.75_0.2_50/0.2)] text-[oklch(0.75_0.2_50)]',
                          item.rarity === 'epic' && 'bg-[oklch(0.65_0.25_320/0.2)] text-[oklch(0.65_0.25_320)]',
                          item.rarity === 'rare' && 'bg-[oklch(0.6_0.2_270/0.2)] text-[oklch(0.6_0.2_270)]',
                          item.rarity === 'uncommon' && 'bg-[oklch(0.65_0.15_200/0.2)] text-[oklch(0.65_0.15_200)]',
                          item.rarity === 'common' && 'bg-secondary text-muted-foreground',
                        )}
                      >
                        {item.name.split(' | ')[0]}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </TabsContent>

        {/* Promo codes tab */}
        <TabsContent value="promos" className="mt-4 space-y-4">
          <Button onClick={() => setShowPromoDialog(true)} className="w-full">
            <Plus className="mr-2 h-4 w-4" />
            {t('createPromo')}
          </Button>

          <div className="space-y-2">
            {promoCodes.map((promo) => (
              <div
                key={promo.id}
                className="flex items-center justify-between rounded-xl border border-border bg-card p-3"
              >
                <div>
                  <p className="font-mono font-semibold text-foreground">{promo.code}</p>
                  <p className="text-xs text-muted-foreground">
                    {promo.value} coins - {promo.currentUses}/{promo.maxUses} uses
                  </p>
                </div>
                <Button
                  size="sm"
                  variant="destructive"
                  onClick={() => deletePromoCode(promo.id)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      {/* Create Promo Dialog */}
      <Dialog open={showPromoDialog} onOpenChange={setShowPromoDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{t('createPromo')}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <Input
              placeholder="Code (e.g., BONUS500)"
              value={promoCode}
              onChange={(e) => setPromoCode(e.target.value.toUpperCase())}
            />
            <Input
              type="number"
              placeholder={t('promoValue')}
              value={promoValue}
              onChange={(e) => setPromoValue(e.target.value)}
            />
            <Input
              type="number"
              placeholder={t('promoUses')}
              value={promoMaxUses}
              onChange={(e) => setPromoMaxUses(e.target.value)}
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowPromoDialog(false)}>
              {t('cancel')}
            </Button>
            <Button onClick={handleCreatePromo}>{t('add')}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Create Case Dialog */}
      <Dialog open={showCaseDialog} onOpenChange={setShowCaseDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add New Case</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <Input
              placeholder="Case Name"
              value={caseName}
              onChange={(e) => setCaseName(e.target.value)}
            />
            <Input
              type="number"
              placeholder={t('casePrice')}
              value={casePrice}
              onChange={(e) => setCasePrice(e.target.value)}
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCaseDialog(false)}>
              {t('cancel')}
            </Button>
            <Button onClick={handleCreateCase}>{t('add')}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add Item Dialog */}
      <Dialog open={showItemDialog} onOpenChange={setShowItemDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Item to Case</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <Input
              placeholder="Item Name (e.g., AK-47 | Redline)"
              value={itemName}
              onChange={(e) => setItemName(e.target.value)}
            />
            <Input
              type="number"
              placeholder={t('price')}
              value={itemPrice}
              onChange={(e) => setItemPrice(e.target.value)}
            />
            <Select value={itemRarity} onValueChange={(v) => setItemRarity(v as Rarity)}>
              <SelectTrigger>
                <SelectValue placeholder={t('rarity')} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="common">{t('common')}</SelectItem>
                <SelectItem value="uncommon">{t('uncommon')}</SelectItem>
                <SelectItem value="rare">{t('rare')}</SelectItem>
                <SelectItem value="epic">{t('epic')}</SelectItem>
                <SelectItem value="legendary">{t('legendary')}</SelectItem>
              </SelectContent>
            </Select>
            <Select value={itemCondition} onValueChange={(v) => setItemCondition(v as Condition)}>
              <SelectTrigger>
                <SelectValue placeholder={t('condition')} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="factoryNew">{t('factoryNew')}</SelectItem>
                <SelectItem value="minimalWear">{t('minimalWear')}</SelectItem>
                <SelectItem value="fieldTested">{t('fieldTested')}</SelectItem>
                <SelectItem value="wellWorn">{t('wellWorn')}</SelectItem>
                <SelectItem value="battleScarred">{t('battleScarred')}</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowItemDialog(false)}>
              {t('cancel')}
            </Button>
            <Button onClick={handleAddItem}>{t('add')}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
