'use client';

import Link from 'next/link';
import { Box, ArrowUpCircle, Trophy, Sparkles } from 'lucide-react';
import { DailyBonus } from '@/components/daily-bonus';
import { PromoCode } from '@/components/promo-code';
import { CaseCard } from '@/components/case-card';
import { useGameStore } from '@/lib/store';
import { getTranslation } from '@/lib/i18n';
import { cn } from '@/lib/utils';

export default function HomePage() {
  const { user, locale, cases } = useGameStore();
  const t = (key: Parameters<typeof getTranslation>[1]) => getTranslation(locale, key);

  return (
    <div className="flex flex-col gap-6 p-4">
      {/* Welcome banner */}
      <div className="relative overflow-hidden rounded-2xl border border-primary/30 bg-gradient-to-br from-primary/10 via-card to-card p-6">
        <div className="absolute -right-8 -top-8 h-32 w-32 rounded-full bg-primary/10 blur-3xl" />
        <div className="relative">
          <h1 className="mb-2 text-xl font-bold text-foreground">
            Welcome back, <span className="text-primary">{user?.name || 'Player'}</span>
          </h1>
          <p className="text-sm text-muted-foreground">
            Open cases, upgrade skins, and dominate the leaderboard
          </p>
        </div>
      </div>

      {/* Daily bonus */}
      <DailyBonus />

      {/* Quick actions */}
      <div className="grid grid-cols-3 gap-3">
        <Link
          href="/cases"
          className="group flex flex-col items-center gap-2 rounded-xl border border-border bg-card p-4 transition-all duration-200 hover:border-primary/50 hover:shadow-[0_0_20px_var(--glow-primary)]"
        >
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary transition-transform duration-200 group-hover:scale-110">
            <Box className="h-6 w-6" />
          </div>
          <span className="text-xs font-medium text-foreground">{t('cases')}</span>
        </Link>

        <Link
          href="/upgrade"
          className="group flex flex-col items-center gap-2 rounded-xl border border-border bg-card p-4 transition-all duration-200 hover:border-accent/50 hover:shadow-[0_0_20px_var(--glow-accent)]"
        >
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-accent/10 text-accent transition-transform duration-200 group-hover:scale-110">
            <ArrowUpCircle className="h-6 w-6" />
          </div>
          <span className="text-xs font-medium text-foreground">{t('upgrade')}</span>
        </Link>

        <Link
          href="/leaderboard"
          className="group flex flex-col items-center gap-2 rounded-xl border border-border bg-card p-4 transition-all duration-200 hover:border-primary/50"
        >
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-secondary text-foreground transition-transform duration-200 group-hover:scale-110">
            <Trophy className="h-6 w-6" />
          </div>
          <span className="text-xs font-medium text-foreground">{t('leaderboard')}</span>
        </Link>
      </div>

      {/* Promo code */}
      <PromoCode />

      {/* Featured cases */}
      <div>
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-semibold text-foreground">{t('cases')}</h2>
          <Link href="/cases" className="text-sm text-primary hover:underline">
            View all
          </Link>
        </div>
        <div className="grid grid-cols-2 gap-3">
          {cases.slice(0, 4).map((caseData) => (
            <CaseCard key={caseData.id} caseData={caseData} />
          ))}
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-3">
        <div className="rounded-xl border border-border bg-card p-4">
          <p className="text-xs text-muted-foreground">{t('totalOpened')}</p>
          <p className="text-2xl font-bold text-foreground">{user?.totalOpened || 0}</p>
        </div>
        <div className="rounded-xl border border-border bg-card p-4">
          <p className="text-xs text-muted-foreground">{t('totalWins')}</p>
          <p className="text-2xl font-bold text-accent">{user?.totalWins || 0}</p>
        </div>
      </div>
    </div>
  );
}
