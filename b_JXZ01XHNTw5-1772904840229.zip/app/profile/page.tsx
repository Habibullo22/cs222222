'use client';

import { useState } from 'react';
import { User, Copy, Check, Users, Calendar, Box, Trophy, Coins, Share2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useGameStore } from '@/lib/store';
import { getTranslation } from '@/lib/i18n';
import { cn } from '@/lib/utils';

export default function ProfilePage() {
  const { user, locale } = useGameStore();
  const t = (key: Parameters<typeof getTranslation>[1]) => getTranslation(locale, key);
  const [copied, setCopied] = useState(false);

  const copyReferralLink = async () => {
    const link = `https://cs2skins.app/ref/${user?.referralCode}`;
    await navigator.clipboard.writeText(link);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const memberSince = user?.createdAt 
    ? new Date(user.createdAt).toLocaleDateString()
    : '-';

  return (
    <div className="flex flex-col gap-6 p-4">
      {/* Profile header */}
      <div className="flex flex-col items-center gap-4 rounded-2xl border border-border bg-card p-6">
        <Avatar className="h-24 w-24 border-4 border-primary/30">
          <AvatarImage src={user?.avatar} alt={user?.name} />
          <AvatarFallback className="bg-primary/10 text-2xl text-primary">
            {user?.name?.charAt(0) || 'U'}
          </AvatarFallback>
        </Avatar>
        
        <div className="text-center">
          <h1 className="text-xl font-bold text-foreground">{user?.name || 'Player'}</h1>
          <p className="text-sm text-muted-foreground">
            {t('userId')}: {user?.id?.slice(0, 8)}
          </p>
        </div>

        {/* Balance */}
        <div className="flex items-center gap-2 rounded-full bg-accent/20 px-6 py-3 border border-accent/30">
          <Coins className="h-6 w-6 text-accent" />
          <span className="text-2xl font-bold text-accent">{user?.balance || 0}</span>
        </div>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 gap-3">
        <div className="flex items-center gap-3 rounded-xl border border-border bg-card p-4">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
            <Box className="h-5 w-5" />
          </div>
          <div>
            <p className="text-xs text-muted-foreground">{t('totalOpened')}</p>
            <p className="text-lg font-bold text-foreground">{user?.totalOpened || 0}</p>
          </div>
        </div>

        <div className="flex items-center gap-3 rounded-xl border border-border bg-card p-4">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent/10 text-accent">
            <Trophy className="h-5 w-5" />
          </div>
          <div>
            <p className="text-xs text-muted-foreground">{t('totalWins')}</p>
            <p className="text-lg font-bold text-accent">{user?.totalWins || 0}</p>
          </div>
        </div>

        <div className="flex items-center gap-3 rounded-xl border border-border bg-card p-4">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-secondary text-foreground">
            <Users className="h-5 w-5" />
          </div>
          <div>
            <p className="text-xs text-muted-foreground">{t('referrals')}</p>
            <p className="text-lg font-bold text-foreground">{user?.referralCount || 0}</p>
          </div>
        </div>

        <div className="flex items-center gap-3 rounded-xl border border-border bg-card p-4">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-secondary text-foreground">
            <Calendar className="h-5 w-5" />
          </div>
          <div>
            <p className="text-xs text-muted-foreground">{t('memberSince')}</p>
            <p className="text-sm font-bold text-foreground">{memberSince}</p>
          </div>
        </div>
      </div>

      {/* Referral section */}
      <div className="rounded-2xl border border-border bg-card p-4">
        <div className="mb-4 flex items-center gap-2">
          <Share2 className="h-5 w-5 text-primary" />
          <h3 className="font-semibold text-foreground">{t('referrals')}</h3>
        </div>

        <p className="mb-4 text-sm text-muted-foreground">
          {t('referralBonus')}: +10 {t('coins')} per referral daily bonus
        </p>

        <div className="flex gap-2">
          <div className="flex-1 rounded-lg bg-secondary/50 px-3 py-2 text-sm font-mono">
            {user?.referralCode || 'REF000'}
          </div>
          <Button onClick={copyReferralLink} className="gap-2">
            {copied ? (
              <>
                <Check className="h-4 w-4" />
                {t('referralCopied')}
              </>
            ) : (
              <>
                <Copy className="h-4 w-4" />
                {t('copyReferral')}
              </>
            )}
          </Button>
        </div>

        {/* Referral stats */}
        <div className="mt-4 flex items-center justify-between rounded-lg bg-primary/10 p-3">
          <span className="text-sm text-muted-foreground">{t('yourReferrals')}</span>
          <span className="text-lg font-bold text-primary">{user?.referralCount || 0}</span>
        </div>
      </div>
    </div>
  );
}
