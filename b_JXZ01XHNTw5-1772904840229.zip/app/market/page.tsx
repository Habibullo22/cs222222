'use client';

import { useState } from 'react';
import { Coins, ShoppingCart, Tag, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ItemCard } from '@/components/item-card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { useGameStore } from '@/lib/store';
import { getTranslation } from '@/lib/i18n';
import type { MarketListing, InventoryItem } from '@/lib/store';
import { cn } from '@/lib/utils';

export default function MarketPage() {
  const { user, locale, inventory, marketListings, buyFromMarket, listItemForSale, cancelListing } = useGameStore();
  const t = (key: Parameters<typeof getTranslation>[1]) => getTranslation(locale, key);
  
  const [selectedListing, setSelectedListing] = useState<MarketListing | null>(null);
  const [listingItem, setListingItem] = useState<InventoryItem | null>(null);
  const [listingPrice, setListingPrice] = useState('');

  const myListings = marketListings.filter(l => l.sellerId === user?.id);

  const handleBuy = (listing: MarketListing) => {
    const success = buyFromMarket(listing.id);
    if (success) {
      setSelectedListing(null);
    }
  };

  const handleList = () => {
    if (!listingItem || !listingPrice) return;
    const price = parseInt(listingPrice);
    if (isNaN(price) || price < 1) return;
    
    listItemForSale(listingItem.id, price);
    setListingItem(null);
    setListingPrice('');
  };

  return (
    <div className="flex flex-col gap-6 p-4">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-foreground">{t('marketplace')}</h1>
        <p className="text-sm text-muted-foreground">
          Buy and sell virtual items
        </p>
      </div>

      <Tabs defaultValue="browse" className="w-full">
        <TabsList className="w-full">
          <TabsTrigger value="browse" className="flex-1">
            <ShoppingCart className="mr-2 h-4 w-4" />
            Browse
          </TabsTrigger>
          <TabsTrigger value="sell" className="flex-1">
            <Tag className="mr-2 h-4 w-4" />
            Sell
          </TabsTrigger>
        </TabsList>

        {/* Browse tab */}
        <TabsContent value="browse" className="mt-4">
          {marketListings.length > 0 ? (
            <div className="grid grid-cols-2 gap-3">
              {marketListings.map((listing) => (
                <div
                  key={listing.id}
                  onClick={() => setSelectedListing(listing)}
                  className="cursor-pointer rounded-xl border border-border bg-card p-3 transition-all hover:border-primary/50 hover:shadow-[0_0_15px_var(--glow-primary)]"
                >
                  <ItemCard item={listing.item} size="sm" showPrice={false} />
                  <div className="mt-2 flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">
                      {listing.sellerName}
                    </span>
                    <div className="flex items-center gap-1">
                      <Coins className="h-3 w-3 text-accent" />
                      <span className="text-sm font-semibold text-accent">
                        {listing.price}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center gap-4 rounded-2xl border border-border bg-card p-12">
              <ShoppingCart className="h-12 w-12 text-muted-foreground" />
              <p className="text-muted-foreground">No items listed</p>
            </div>
          )}
        </TabsContent>

        {/* Sell tab */}
        <TabsContent value="sell" className="mt-4 space-y-4">
          {/* My listings */}
          {myListings.length > 0 && (
            <div className="rounded-xl border border-border bg-card p-4">
              <h3 className="mb-3 text-sm font-semibold">{t('yourListings')}</h3>
              <div className="space-y-2">
                {myListings.map((listing) => (
                  <div
                    key={listing.id}
                    className="flex items-center justify-between rounded-lg bg-secondary/50 p-2"
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-sm">{listing.item.name}</span>
                      <span className="text-xs text-accent">{listing.price}</span>
                    </div>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => cancelListing(listing.id)}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* List new item */}
          <div className="rounded-xl border border-border bg-card p-4">
            <h3 className="mb-3 text-sm font-semibold">{t('listItem')}</h3>
            
            {listingItem ? (
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <ItemCard item={listingItem} size="sm" showPrice={false} />
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => setListingItem(null)}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
                <div className="flex gap-2">
                  <Input
                    type="number"
                    placeholder={t('price')}
                    value={listingPrice}
                    onChange={(e) => setListingPrice(e.target.value)}
                    className="flex-1"
                  />
                  <Button onClick={handleList} disabled={!listingPrice}>
                    {t('listItem')}
                  </Button>
                </div>
              </div>
            ) : inventory.length > 0 ? (
              <div className="grid grid-cols-3 gap-2">
                {inventory.map((item) => (
                  <ItemCard
                    key={item.id}
                    item={item}
                    size="sm"
                    onClick={() => setListingItem(item)}
                  />
                ))}
              </div>
            ) : (
              <p className="text-center text-sm text-muted-foreground py-4">
                {t('emptyInventory')}
              </p>
            )}
          </div>
        </TabsContent>
      </Tabs>

      {/* Buy dialog */}
      <Dialog open={!!selectedListing} onOpenChange={() => setSelectedListing(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>{t('itemDetails')}</DialogTitle>
          </DialogHeader>
          
          {selectedListing && (
            <div className="flex flex-col items-center gap-4 py-4">
              <ItemCard item={selectedListing.item} size="lg" showPrice={false} />
              
              <div className="w-full space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Seller</span>
                  <span className="font-medium">{selectedListing.sellerName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">{t('price')}</span>
                  <span className="font-semibold text-accent">{selectedListing.price}</span>
                </div>
              </div>
            </div>
          )}

          <DialogFooter>
            <Button
              onClick={() => selectedListing && handleBuy(selectedListing)}
              disabled={!selectedListing || (user?.balance || 0) < (selectedListing?.price || 0)}
              className="w-full bg-primary hover:bg-primary/90"
            >
              <Coins className="mr-2 h-4 w-4" />
              {t('buyNow')}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
