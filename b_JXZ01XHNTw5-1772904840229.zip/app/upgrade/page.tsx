'use client';

import { UpgradeGame } from '@/components/upgrade-game';
import { useGameStore } from '@/lib/store';
import { getTranslation } from '@/lib/i18n';

export default function UpgradePage() {
  const { locale } = useGameStore();
  const t = (key: Parameters<typeof getTranslation>[1]) => getTranslation(locale, key);

  return (
    <div className="flex flex-col gap-6 p-4">
      <div>
        <h1 className="text-2xl font-bold text-foreground">{t('upgradeTitle')}</h1>
        <p className="text-sm text-muted-foreground">
          Risk your items for a chance at better ones
        </p>
      </div>

      <UpgradeGame />
    </div>
  );
}
