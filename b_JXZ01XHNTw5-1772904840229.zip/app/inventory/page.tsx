'use client';

import { useState } from 'react';
import { Coins, Package, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ItemCard } from '@/components/item-card';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { useGameStore } from '@/lib/store';
import { getTranslation } from '@/lib/i18n';
import type { InventoryItem } from '@/lib/store';

export default function InventoryPage() {
  const { locale, inventory, sellItem } = useGameStore();
  const t = (key: Parameters<typeof getTranslation>[1]) => getTranslation(locale, key);
  
  const [selectedItem, setSelectedItem] = useState<InventoryItem | null>(null);

  const totalValue = inventory.reduce((sum, item) => sum + item.price, 0);
  const sellValue = Math.floor(totalValue * 0.8);

  const handleSellItem = (item: InventoryItem) => {
    sellItem(item.id);
    setSelectedItem(null);
  };

  const handleSellAll = () => {
    inventory.forEach(item => sellItem(item.id));
  };

  return (
    <div className="flex flex-col gap-6 p-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">{t('myInventory')}</h1>
          <p className="text-sm text-muted-foreground">
            {inventory.length} items
          </p>
        </div>
        {inventory.length > 0 && (
          <div className="flex items-center gap-2 rounded-xl bg-accent/10 px-3 py-2">
            <Coins className="h-4 w-4 text-accent" />
            <span className="text-sm font-semibold text-accent">{totalValue}</span>
          </div>
        )}
      </div>

      {/* Sell all button */}
      {inventory.length > 1 && (
        <Button
          onClick={handleSellAll}
          variant="outline"
          className="border-accent/30 text-accent hover:bg-accent/10"
        >
          <Trash2 className="mr-2 h-4 w-4" />
          {t('sellAll')} ({sellValue} {t('coins')})
        </Button>
      )}

      {/* Items grid */}
      {inventory.length > 0 ? (
        <div className="grid grid-cols-3 gap-3">
          {inventory.map((item) => (
            <ItemCard
              key={item.id}
              item={item}
              onClick={() => setSelectedItem(item)}
            />
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center gap-4 rounded-2xl border border-border bg-card p-12">
          <div className="flex h-16 w-16 items-center justify-center rounded-full bg-secondary">
            <Package className="h-8 w-8 text-muted-foreground" />
          </div>
          <p className="text-muted-foreground">{t('emptyInventory')}</p>
          <Button asChild>
            <a href="/cases">{t('openCase')}</a>
          </Button>
        </div>
      )}

      {/* Item detail dialog */}
      <Dialog open={!!selectedItem} onOpenChange={() => setSelectedItem(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>{t('itemDetails')}</DialogTitle>
          </DialogHeader>
          
          {selectedItem && (
            <div className="flex flex-col items-center gap-4 py-4">
              <ItemCard item={selectedItem} size="lg" showPrice={false} />
              
              <div className="w-full space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">{t('rarity')}</span>
                  <span className="font-medium capitalize">{t(selectedItem.rarity)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">{t('condition')}</span>
                  <span className="font-medium">{t(selectedItem.condition)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">{t('price')}</span>
                  <span className="font-semibold text-accent">{selectedItem.price}</span>
                </div>
              </div>
            </div>
          )}

          <DialogFooter className="gap-2">
            <Button
              variant="outline"
              onClick={() => setSelectedItem(null)}
              className="flex-1"
            >
              {t('keepItem')}
            </Button>
            <Button
              onClick={() => selectedItem && handleSellItem(selectedItem)}
              className="flex-1 bg-accent text-accent-foreground hover:bg-accent/90"
            >
              <Coins className="mr-2 h-4 w-4" />
              {t('sellItem')} ({Math.floor(selectedItem?.price ?? 0 * 0.8)})
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
