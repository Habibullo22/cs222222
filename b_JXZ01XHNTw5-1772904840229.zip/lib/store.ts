import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { Locale } from './i18n';

export type Rarity = 'common' | 'uncommon' | 'rare' | 'epic' | 'legendary';
export type Condition = 'factoryNew' | 'minimalWear' | 'fieldTested' | 'wellWorn' | 'battleScarred';

export interface Item {
  id: string;
  name: string;
  image: string;
  rarity: Rarity;
  condition: Condition;
  price: number;
}

export interface Case {
  id: string;
  name: string;
  image: string;
  price: number;
  items: Item[];
}

export interface InventoryItem extends Item {
  ownerId: string;
  acquiredAt: number;
}

export interface MarketListing {
  id: string;
  item: Item;
  sellerId: string;
  sellerName: string;
  price: number;
  listedAt: number;
}

export interface User {
  id: string;
  name: string;
  avatar: string;
  balance: number;
  totalWins: number;
  totalOpened: number;
  referralCode: string;
  referredBy?: string;
  referralCount: number;
  lastDailyBonus?: number;
  isAdmin: boolean;
  createdAt: number;
}

export interface PromoCode {
  id: string;
  code: string;
  value: number;
  maxUses: number;
  currentUses: number;
  active: boolean;
}

interface GameState {
  // User
  user: User | null;
  locale: Locale;
  
  // Data
  cases: Case[];
  inventory: InventoryItem[];
  marketListings: MarketListing[];
  promoCodes: PromoCode[];
  allUsers: User[];
  
  // Actions
  setLocale: (locale: Locale) => void;
  setUser: (user: User) => void;
  updateBalance: (amount: number) => void;
  claimDailyBonus: () => boolean;
  applyPromoCode: (code: string) => { success: boolean; message: string };
  
  // Inventory
  addToInventory: (item: Item) => void;
  removeFromInventory: (itemId: string) => void;
  sellItem: (itemId: string) => void;
  
  // Market
  listItemForSale: (itemId: string, price: number) => void;
  buyFromMarket: (listingId: string) => boolean;
  cancelListing: (listingId: string) => void;
  
  // Case opening
  openCase: (caseId: string) => Item | null;
  
  // Admin
  addCase: (caseData: Omit<Case, 'id'>) => void;
  updateCase: (caseId: string, caseData: Partial<Case>) => void;
  deleteCase: (caseId: string) => void;
  addItem: (caseId: string, item: Omit<Item, 'id'>) => void;
  createPromoCode: (code: string, value: number, maxUses: number) => void;
  deletePromoCode: (promoId: string) => void;
}

// Sample data
const sampleItems: Item[] = [
  { id: '1', name: 'AK-47 | Redline', image: '/items/ak47-redline.jpg', rarity: 'rare', condition: 'fieldTested', price: 250 },
  { id: '2', name: 'AWP | Dragon Lore', image: '/items/awp-dragon.jpg', rarity: 'legendary', condition: 'factoryNew', price: 5000 },
  { id: '3', name: 'M4A4 | Howl', image: '/items/m4a4-howl.jpg', rarity: 'legendary', condition: 'minimalWear', price: 4500 },
  { id: '4', name: 'Glock-18 | Fade', image: '/items/glock-fade.jpg', rarity: 'epic', condition: 'factoryNew', price: 800 },
  { id: '5', name: 'USP-S | Kill Confirmed', image: '/items/usp-kill.jpg', rarity: 'epic', condition: 'minimalWear', price: 600 },
  { id: '6', name: 'Desert Eagle | Blaze', image: '/items/deagle-blaze.jpg', rarity: 'rare', condition: 'factoryNew', price: 350 },
  { id: '7', name: 'P250 | Mehndi', image: '/items/p250-mehndi.jpg', rarity: 'uncommon', condition: 'fieldTested', price: 80 },
  { id: '8', name: 'Five-SeveN | Monkey Business', image: '/items/57-monkey.jpg', rarity: 'uncommon', condition: 'wellWorn', price: 50 },
  { id: '9', name: 'P90 | Asiimov', image: '/items/p90-asiimov.jpg', rarity: 'rare', condition: 'minimalWear', price: 200 },
  { id: '10', name: 'MAC-10 | Neon Rider', image: '/items/mac10-neon.jpg', rarity: 'uncommon', condition: 'factoryNew', price: 120 },
  { id: '11', name: 'UMP-45 | Blaze', image: '/items/ump-blaze.jpg', rarity: 'common', condition: 'fieldTested', price: 30 },
  { id: '12', name: 'MP7 | Bloodsport', image: '/items/mp7-blood.jpg', rarity: 'rare', condition: 'minimalWear', price: 180 },
];

const sampleCases: Case[] = [
  {
    id: 'case-1',
    name: 'Starter Case',
    image: '/cases/starter.jpg',
    price: 100,
    items: sampleItems.slice(0, 4),
  },
  {
    id: 'case-2',
    name: 'Premium Case',
    image: '/cases/premium.jpg',
    price: 500,
    items: sampleItems.slice(2, 8),
  },
  {
    id: 'case-3',
    name: 'Elite Case',
    image: '/cases/elite.jpg',
    price: 1000,
    items: sampleItems.slice(4, 10),
  },
  {
    id: 'case-4',
    name: 'Legendary Case',
    image: '/cases/legendary.jpg',
    price: 2500,
    items: sampleItems.filter(i => i.rarity === 'legendary' || i.rarity === 'epic'),
  },
];

const defaultUser: User = {
  id: 'user-1',
  name: 'Player',
  avatar: '',
  balance: 1000,
  totalWins: 0,
  totalOpened: 0,
  referralCode: 'REF123',
  referralCount: 0,
  isAdmin: true,
  createdAt: Date.now(),
};

function generateId(): string {
  return Math.random().toString(36).substring(2, 15);
}

function getRandomItem(items: Item[]): Item {
  // Weighted random based on rarity
  const weights: Record<Rarity, number> = {
    common: 40,
    uncommon: 30,
    rare: 18,
    epic: 9,
    legendary: 3,
  };
  
  const weightedItems = items.flatMap(item => 
    Array(weights[item.rarity]).fill(item)
  );
  
  return weightedItems[Math.floor(Math.random() * weightedItems.length)];
}

export const useGameStore = create<GameState>()(
  persist(
    (set, get) => ({
      user: defaultUser,
      locale: 'en',
      cases: sampleCases,
      inventory: [],
      marketListings: [],
      promoCodes: [
        { id: 'promo-1', code: 'WELCOME100', value: 100, maxUses: 1000, currentUses: 0, active: true },
        { id: 'promo-2', code: 'VIP500', value: 500, maxUses: 100, currentUses: 0, active: true },
      ],
      allUsers: [defaultUser],
      
      setLocale: (locale) => set({ locale }),
      
      setUser: (user) => set({ user }),
      
      updateBalance: (amount) => set((state) => ({
        user: state.user ? { ...state.user, balance: state.user.balance + amount } : null,
      })),
      
      claimDailyBonus: () => {
        const state = get();
        if (!state.user) return false;
        
        const now = Date.now();
        const lastBonus = state.user.lastDailyBonus || 0;
        const oneDayMs = 24 * 60 * 60 * 1000;
        
        if (now - lastBonus < oneDayMs) return false;
        
        const bonusAmount = 50 + (state.user.referralCount * 10);
        
        set({
          user: {
            ...state.user,
            balance: state.user.balance + bonusAmount,
            lastDailyBonus: now,
          },
        });
        
        return true;
      },
      
      applyPromoCode: (code) => {
        const state = get();
        if (!state.user) return { success: false, message: 'Not logged in' };
        
        const promo = state.promoCodes.find(p => p.code.toUpperCase() === code.toUpperCase() && p.active);
        
        if (!promo) return { success: false, message: 'Invalid promo code' };
        if (promo.currentUses >= promo.maxUses) return { success: false, message: 'Promo code expired' };
        
        set({
          user: { ...state.user, balance: state.user.balance + promo.value },
          promoCodes: state.promoCodes.map(p => 
            p.id === promo.id ? { ...p, currentUses: p.currentUses + 1 } : p
          ),
        });
        
        return { success: true, message: `Added ${promo.value} coins!` };
      },
      
      addToInventory: (item) => set((state) => ({
        inventory: [
          ...state.inventory,
          {
            ...item,
            id: generateId(),
            ownerId: state.user?.id || '',
            acquiredAt: Date.now(),
          },
        ],
      })),
      
      removeFromInventory: (itemId) => set((state) => ({
        inventory: state.inventory.filter(i => i.id !== itemId),
      })),
      
      sellItem: (itemId) => {
        const state = get();
        const item = state.inventory.find(i => i.id === itemId);
        if (!item || !state.user) return;
        
        set({
          inventory: state.inventory.filter(i => i.id !== itemId),
          user: { ...state.user, balance: state.user.balance + Math.floor(item.price * 0.8) },
        });
      },
      
      listItemForSale: (itemId, price) => {
        const state = get();
        const item = state.inventory.find(i => i.id === itemId);
        if (!item || !state.user) return;
        
        set({
          inventory: state.inventory.filter(i => i.id !== itemId),
          marketListings: [
            ...state.marketListings,
            {
              id: generateId(),
              item,
              sellerId: state.user.id,
              sellerName: state.user.name,
              price,
              listedAt: Date.now(),
            },
          ],
        });
      },
      
      buyFromMarket: (listingId) => {
        const state = get();
        const listing = state.marketListings.find(l => l.id === listingId);
        if (!listing || !state.user) return false;
        if (state.user.balance < listing.price) return false;
        
        set({
          user: { ...state.user, balance: state.user.balance - listing.price },
          marketListings: state.marketListings.filter(l => l.id !== listingId),
          inventory: [
            ...state.inventory,
            {
              ...listing.item,
              id: generateId(),
              ownerId: state.user.id,
              acquiredAt: Date.now(),
            },
          ],
        });
        
        return true;
      },
      
      cancelListing: (listingId) => {
        const state = get();
        const listing = state.marketListings.find(l => l.id === listingId);
        if (!listing || !state.user || listing.sellerId !== state.user.id) return;
        
        set({
          marketListings: state.marketListings.filter(l => l.id !== listingId),
          inventory: [
            ...state.inventory,
            {
              ...listing.item,
              id: generateId(),
              ownerId: state.user.id,
              acquiredAt: Date.now(),
            },
          ],
        });
      },
      
      openCase: (caseId) => {
        const state = get();
        const caseData = state.cases.find(c => c.id === caseId);
        if (!caseData || !state.user) return null;
        if (state.user.balance < caseData.price) return null;
        
        const wonItem = getRandomItem(caseData.items);
        
        set({
          user: {
            ...state.user,
            balance: state.user.balance - caseData.price,
            totalOpened: state.user.totalOpened + 1,
            totalWins: state.user.totalWins + wonItem.price,
          },
          inventory: [
            ...state.inventory,
            {
              ...wonItem,
              id: generateId(),
              ownerId: state.user.id,
              acquiredAt: Date.now(),
            },
          ],
        });
        
        return wonItem;
      },
      
      addCase: (caseData) => set((state) => ({
        cases: [...state.cases, { ...caseData, id: generateId() }],
      })),
      
      updateCase: (caseId, caseData) => set((state) => ({
        cases: state.cases.map(c => c.id === caseId ? { ...c, ...caseData } : c),
      })),
      
      deleteCase: (caseId) => set((state) => ({
        cases: state.cases.filter(c => c.id !== caseId),
      })),
      
      addItem: (caseId, item) => set((state) => ({
        cases: state.cases.map(c => 
          c.id === caseId 
            ? { ...c, items: [...c.items, { ...item, id: generateId() }] }
            : c
        ),
      })),
      
      createPromoCode: (code, value, maxUses) => set((state) => ({
        promoCodes: [
          ...state.promoCodes,
          { id: generateId(), code, value, maxUses, currentUses: 0, active: true },
        ],
      })),
      
      deletePromoCode: (promoId) => set((state) => ({
        promoCodes: state.promoCodes.filter(p => p.id !== promoId),
      })),
    }),
    {
      name: 'cs2-game-storage',
    }
  )
);
