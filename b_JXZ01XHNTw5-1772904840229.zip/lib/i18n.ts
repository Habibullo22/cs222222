export type Locale = 'en' | 'ru' | 'uz';

export const translations = {
  en: {
    // Navigation
    home: 'Home',
    cases: 'Cases',
    upgrade: 'Upgrade',
    inventory: 'Inventory',
    market: 'Market',
    profile: 'Profile',
    admin: 'Admin',
    leaderboard: 'Leaderboard',
    
    // Common
    balance: 'Balance',
    coins: 'Coins',
    dailyBonus: 'Daily Bonus',
    claim: 'Claim',
    claimed: 'Claimed',
    referrals: 'Referrals',
    promoCode: 'Promo Code',
    apply: 'Apply',
    cancel: 'Cancel',
    save: 'Save',
    delete: 'Delete',
    edit: 'Edit',
    add: 'Add',
    search: 'Search',
    loading: 'Loading...',
    success: 'Success!',
    error: 'Error',
    
    // Profile
    userId: 'User ID',
    totalWins: 'Total Wins',
    totalOpened: 'Cases Opened',
    memberSince: 'Member Since',
    copyReferral: 'Copy Referral Link',
    referralCopied: 'Referral link copied!',
    yourReferrals: 'Your Referrals',
    referralBonus: 'Referral Bonus',
    
    // Cases
    openCase: 'Open Case',
    openAgain: 'Open Again',
    casePrice: 'Price',
    possibleWins: 'Possible Wins',
    opening: 'Opening...',
    youWon: 'You Won!',
    sellItem: 'Sell',
    keepItem: 'Keep',
    
    // Upgrade
    upgradeTitle: 'Upgrade Game',
    selectItem: 'Select Item',
    targetItem: 'Target Item',
    successChance: 'Success Chance',
    startUpgrade: 'Start Upgrade',
    upgradeWin: 'Upgrade Successful!',
    upgradeLose: 'Upgrade Failed',
    
    // Inventory
    myInventory: 'My Inventory',
    emptyInventory: 'Your inventory is empty',
    totalValue: 'Total Value',
    sellAll: 'Sell All',
    
    // Market
    marketplace: 'Marketplace',
    buyNow: 'Buy Now',
    listItem: 'List Item',
    yourListings: 'Your Listings',
    
    // Item Details
    itemDetails: 'Item Details',
    rarity: 'Rarity',
    condition: 'Condition',
    price: 'Price',
    
    // Leaderboard
    topPlayers: 'Top Players',
    rank: 'Rank',
    player: 'Player',
    winnings: 'Winnings',
    
    // Admin
    adminPanel: 'Admin Panel',
    manageItems: 'Manage Items',
    manageCases: 'Manage Cases',
    manageUsers: 'Manage Users',
    promoCodes: 'Promo Codes',
    statistics: 'Statistics',
    createPromo: 'Create Promo Code',
    promoValue: 'Value',
    promoUses: 'Max Uses',
    totalUsers: 'Total Users',
    totalCasesOpened: 'Total Cases Opened',
    totalCoinsSpent: 'Total Coins Spent',
    activeUsers: 'Active Users',
    
    // Rarity
    common: 'Common',
    uncommon: 'Uncommon',
    rare: 'Rare',
    epic: 'Epic',
    legendary: 'Legendary',
    
    // Conditions
    factoryNew: 'Factory New',
    minimalWear: 'Minimal Wear',
    fieldTested: 'Field-Tested',
    wellWorn: 'Well-Worn',
    battleScarred: 'Battle-Scarred',
    
    // Language
    language: 'Language',
    english: 'English',
    russian: 'Russian',
    uzbek: 'Uzbek',
  },
  ru: {
    // Navigation
    home: 'Главная',
    cases: 'Кейсы',
    upgrade: 'Апгрейд',
    inventory: 'Инвентарь',
    market: 'Маркет',
    profile: 'Профиль',
    admin: 'Админ',
    leaderboard: 'Рейтинг',
    
    // Common
    balance: 'Баланс',
    coins: 'Монеты',
    dailyBonus: 'Ежедневный бонус',
    claim: 'Забрать',
    claimed: 'Получено',
    referrals: 'Рефералы',
    promoCode: 'Промокод',
    apply: 'Применить',
    cancel: 'Отмена',
    save: 'Сохранить',
    delete: 'Удалить',
    edit: 'Редактировать',
    add: 'Добавить',
    search: 'Поиск',
    loading: 'Загрузка...',
    success: 'Успех!',
    error: 'Ошибка',
    
    // Profile
    userId: 'ID пользователя',
    totalWins: 'Всего выигрышей',
    totalOpened: 'Открыто кейсов',
    memberSince: 'Участник с',
    copyReferral: 'Копировать реферальную ссылку',
    referralCopied: 'Ссылка скопирована!',
    yourReferrals: 'Ваши рефералы',
    referralBonus: 'Реферальный бонус',
    
    // Cases
    openCase: 'Открыть кейс',
    openAgain: 'Открыть снова',
    casePrice: 'Цена',
    possibleWins: 'Возможные выигрыши',
    opening: 'Открытие...',
    youWon: 'Вы выиграли!',
    sellItem: 'Продать',
    keepItem: 'Оставить',
    
    // Upgrade
    upgradeTitle: 'Игра на повышение',
    selectItem: 'Выберите предмет',
    targetItem: 'Целевой предмет',
    successChance: 'Шанс успеха',
    startUpgrade: 'Начать апгрейд',
    upgradeWin: 'Апгрейд успешен!',
    upgradeLose: 'Апгрейд провален',
    
    // Inventory
    myInventory: 'Мой инвентарь',
    emptyInventory: 'Ваш инвентарь пуст',
    totalValue: 'Общая стоимость',
    sellAll: 'Продать всё',
    
    // Market
    marketplace: 'Маркетплейс',
    buyNow: 'Купить',
    listItem: 'Выставить',
    yourListings: 'Ваши лоты',
    
    // Item Details
    itemDetails: 'Информация о предмете',
    rarity: 'Редкость',
    condition: 'Состояние',
    price: 'Цена',
    
    // Leaderboard
    topPlayers: 'Топ игроков',
    rank: 'Место',
    player: 'Игрок',
    winnings: 'Выигрыши',
    
    // Admin
    adminPanel: 'Панель администратора',
    manageItems: 'Управление предметами',
    manageCases: 'Управление кейсами',
    manageUsers: 'Управление пользователями',
    promoCodes: 'Промокоды',
    statistics: 'Статистика',
    createPromo: 'Создать промокод',
    promoValue: 'Значение',
    promoUses: 'Макс. использований',
    totalUsers: 'Всего пользователей',
    totalCasesOpened: 'Всего открыто кейсов',
    totalCoinsSpent: 'Всего потрачено монет',
    activeUsers: 'Активные пользователи',
    
    // Rarity
    common: 'Обычный',
    uncommon: 'Необычный',
    rare: 'Редкий',
    epic: 'Эпический',
    legendary: 'Легендарный',
    
    // Conditions
    factoryNew: 'Прямо с завода',
    minimalWear: 'Немного поношенное',
    fieldTested: 'После полевых испытаний',
    wellWorn: 'Поношенное',
    battleScarred: 'Закалённое в боях',
    
    // Language
    language: 'Язык',
    english: 'Английский',
    russian: 'Русский',
    uzbek: 'Узбекский',
  },
  uz: {
    // Navigation
    home: 'Bosh sahifa',
    cases: 'Keyslar',
    upgrade: 'Yangilash',
    inventory: 'Inventar',
    market: 'Bozor',
    profile: 'Profil',
    admin: 'Admin',
    leaderboard: 'Reyting',
    
    // Common
    balance: 'Balans',
    coins: 'Tangalar',
    dailyBonus: 'Kunlik bonus',
    claim: 'Olish',
    claimed: 'Olingan',
    referrals: 'Referallar',
    promoCode: 'Promokod',
    apply: 'Qo\'llash',
    cancel: 'Bekor qilish',
    save: 'Saqlash',
    delete: 'O\'chirish',
    edit: 'Tahrirlash',
    add: 'Qo\'shish',
    search: 'Qidirish',
    loading: 'Yuklanmoqda...',
    success: 'Muvaffaqiyat!',
    error: 'Xato',
    
    // Profile
    userId: 'Foydalanuvchi ID',
    totalWins: 'Jami yutuqlar',
    totalOpened: 'Ochilgan keyslar',
    memberSince: 'A\'zo bo\'lgan sana',
    copyReferral: 'Referal havolasini nusxalash',
    referralCopied: 'Havola nusxalandi!',
    yourReferrals: 'Sizning referallaringiz',
    referralBonus: 'Referal bonusi',
    
    // Cases
    openCase: 'Keysni ochish',
    openAgain: 'Yana ochish',
    casePrice: 'Narx',
    possibleWins: 'Mumkin bo\'lgan yutuqlar',
    opening: 'Ochilmoqda...',
    youWon: 'Siz yutdingiz!',
    sellItem: 'Sotish',
    keepItem: 'Saqlab qolish',
    
    // Upgrade
    upgradeTitle: 'Yangilash o\'yini',
    selectItem: 'Buyumni tanlang',
    targetItem: 'Maqsadli buyum',
    successChance: 'Muvaffaqiyat imkoniyati',
    startUpgrade: 'Yangilashni boshlash',
    upgradeWin: 'Yangilash muvaffaqiyatli!',
    upgradeLose: 'Yangilash muvaffaqiyatsiz',
    
    // Inventory
    myInventory: 'Mening inventarim',
    emptyInventory: 'Inventaringiz bo\'sh',
    totalValue: 'Umumiy qiymat',
    sellAll: 'Hammasini sotish',
    
    // Market
    marketplace: 'Bozor',
    buyNow: 'Sotib olish',
    listItem: 'Sotuvga qo\'yish',
    yourListings: 'Sizning e\'lonlaringiz',
    
    // Item Details
    itemDetails: 'Buyum tafsilotlari',
    rarity: 'Nodirligi',
    condition: 'Holati',
    price: 'Narx',
    
    // Leaderboard
    topPlayers: 'Top o\'yinchilar',
    rank: 'O\'rin',
    player: 'O\'yinchi',
    winnings: 'Yutuqlar',
    
    // Admin
    adminPanel: 'Admin paneli',
    manageItems: 'Buyumlarni boshqarish',
    manageCases: 'Keyslarni boshqarish',
    manageUsers: 'Foydalanuvchilarni boshqarish',
    promoCodes: 'Promokodlar',
    statistics: 'Statistika',
    createPromo: 'Promokod yaratish',
    promoValue: 'Qiymat',
    promoUses: 'Maks. foydalanish',
    totalUsers: 'Jami foydalanuvchilar',
    totalCasesOpened: 'Jami ochilgan keyslar',
    totalCoinsSpent: 'Jami sarflangan tangalar',
    activeUsers: 'Faol foydalanuvchilar',
    
    // Rarity
    common: 'Oddiy',
    uncommon: 'Kam uchraydigan',
    rare: 'Nodir',
    epic: 'Epik',
    legendary: 'Afsonaviy',
    
    // Conditions
    factoryNew: 'Zavoddan yangi',
    minimalWear: 'Minimal eskirish',
    fieldTested: 'Dala sinovidan o\'tgan',
    wellWorn: 'Yaxshi ishlatilgan',
    battleScarred: 'Jangda singan',
    
    // Language
    language: 'Til',
    english: 'Inglizcha',
    russian: 'Ruscha',
    uzbek: 'O\'zbekcha',
  },
} as const;

export type TranslationKey = keyof typeof translations.en;

export function getTranslation(locale: Locale, key: TranslationKey): string {
  return translations[locale][key] || translations.en[key] || key;
}
