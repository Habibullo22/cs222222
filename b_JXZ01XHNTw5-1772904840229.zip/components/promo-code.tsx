'use client';

import { useState } from 'react';
import { Ticket, Check, X, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useGameStore } from '@/lib/store';
import { getTranslation } from '@/lib/i18n';
import { cn } from '@/lib/utils';

export function PromoCode() {
  const { locale, applyPromoCode } = useGameStore();
  const t = (key: Parameters<typeof getTranslation>[1]) => getTranslation(locale, key);
  
  const [code, setCode] = useState('');
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [message, setMessage] = useState('');

  const handleApply = async () => {
    if (!code.trim()) return;
    
    setStatus('loading');
    
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const result = applyPromoCode(code);
    
    if (result.success) {
      setStatus('success');
      setMessage(result.message);
      setCode('');
      setTimeout(() => setStatus('idle'), 2000);
    } else {
      setStatus('error');
      setMessage(result.message);
      setTimeout(() => setStatus('idle'), 2000);
    }
  };

  return (
    <div className="rounded-2xl border border-border bg-card p-4">
      <div className="mb-3 flex items-center gap-2">
        <Ticket className="h-5 w-5 text-primary" />
        <h3 className="text-sm font-semibold text-foreground">{t('promoCode')}</h3>
      </div>

      <div className="flex gap-2">
        <Input
          value={code}
          onChange={(e) => setCode(e.target.value.toUpperCase())}
          placeholder="ENTER CODE"
          className={cn(
            'flex-1 bg-secondary/50 border-border uppercase tracking-wider transition-all duration-200',
            status === 'success' && 'border-primary bg-primary/10',
            status === 'error' && 'border-destructive bg-destructive/10'
          )}
          disabled={status === 'loading'}
        />
        <Button
          onClick={handleApply}
          disabled={!code.trim() || status === 'loading'}
          className="min-w-[80px]"
          size="default"
        >
          {status === 'loading' ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : status === 'success' ? (
            <Check className="h-4 w-4" />
          ) : status === 'error' ? (
            <X className="h-4 w-4" />
          ) : (
            t('apply')
          )}
        </Button>
      </div>

      {message && (
        <p className={cn(
          'mt-2 text-xs transition-all duration-200',
          status === 'success' ? 'text-primary' : 'text-destructive'
        )}>
          {message}
        </p>
      )}
    </div>
  );
}
