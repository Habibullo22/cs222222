'use client';

import Image from 'next/image';
import { Coins } from 'lucide-react';
import { cn } from '@/lib/utils';
import type { Item, Rarity } from '@/lib/store';
import { useGameStore } from '@/lib/store';
import { getTranslation } from '@/lib/i18n';

const rarityColors: Record<Rarity, string> = {
  common: 'from-[var(--rarity-common)] to-[var(--rarity-common)]/50',
  uncommon: 'from-[var(--rarity-uncommon)] to-[var(--rarity-uncommon)]/50',
  rare: 'from-[var(--rarity-rare)] to-[var(--rarity-rare)]/50',
  epic: 'from-[var(--rarity-epic)] to-[var(--rarity-epic)]/50',
  legendary: 'from-[var(--rarity-legendary)] to-[var(--rarity-legendary)]/50',
};

const rarityBorders: Record<Rarity, string> = {
  common: 'border-[oklch(0.6_0_0)]',
  uncommon: 'border-[oklch(0.65_0.15_200)]',
  rare: 'border-[oklch(0.6_0.2_270)]',
  epic: 'border-[oklch(0.65_0.25_320)]',
  legendary: 'border-[oklch(0.75_0.2_50)]',
};

const rarityGlow: Record<Rarity, string> = {
  common: '',
  uncommon: 'shadow-[0_0_15px_oklch(0.65_0.15_200/0.3)]',
  rare: 'shadow-[0_0_20px_oklch(0.6_0.2_270/0.4)]',
  epic: 'shadow-[0_0_25px_oklch(0.65_0.25_320/0.5)]',
  legendary: 'shadow-[0_0_30px_oklch(0.75_0.2_50/0.6)]',
};

interface ItemCardProps {
  item: Item;
  onClick?: () => void;
  showPrice?: boolean;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

export function ItemCard({ item, onClick, showPrice = true, size = 'md', className }: ItemCardProps) {
  const locale = useGameStore((state) => state.locale);
  const t = (key: Parameters<typeof getTranslation>[1]) => getTranslation(locale, key);

  const sizeClasses = {
    sm: 'h-24 w-24',
    md: 'h-32 w-32',
    lg: 'h-40 w-40',
  };

  const imageSizes = {
    sm: 60,
    md: 80,
    lg: 100,
  };

  return (
    <div
      onClick={onClick}
      className={cn(
        'group relative flex flex-col items-center justify-center rounded-xl border-2 bg-card p-3 transition-all duration-300',
        rarityBorders[item.rarity],
        rarityGlow[item.rarity],
        onClick && 'cursor-pointer hover:scale-105',
        sizeClasses[size],
        className
      )}
    >
      {/* Rarity gradient overlay */}
      <div className={cn(
        'absolute inset-0 rounded-xl bg-gradient-to-b opacity-20',
        rarityColors[item.rarity]
      )} />

      {/* Item image placeholder */}
      <div className="relative z-10 mb-2 flex items-center justify-center">
        <div 
          className={cn(
            'flex items-center justify-center rounded-lg bg-secondary/50',
            size === 'sm' ? 'h-12 w-12' : size === 'md' ? 'h-16 w-16' : 'h-20 w-20'
          )}
        >
          <span className="text-2xl">🔫</span>
        </div>
      </div>

      {/* Item name */}
      <p className={cn(
        'relative z-10 text-center font-medium leading-tight text-foreground',
        size === 'sm' ? 'text-[10px]' : size === 'md' ? 'text-xs' : 'text-sm'
      )}>
        {item.name.split(' | ')[0]}
      </p>

      {/* Price */}
      {showPrice && (
        <div className="relative z-10 mt-1 flex items-center gap-0.5">
          <Coins className={cn(
            'text-accent',
            size === 'sm' ? 'h-3 w-3' : 'h-3.5 w-3.5'
          )} />
          <span className={cn(
            'font-semibold text-accent',
            size === 'sm' ? 'text-[10px]' : 'text-xs'
          )}>
            {item.price}
          </span>
        </div>
      )}

      {/* Rarity badge */}
      <div className={cn(
        'absolute -top-1 -right-1 rounded-full px-1.5 py-0.5 text-[8px] font-bold uppercase',
        item.rarity === 'legendary' && 'bg-[oklch(0.75_0.2_50)] text-[oklch(0.12_0.01_260)]',
        item.rarity === 'epic' && 'bg-[oklch(0.65_0.25_320)] text-foreground',
        item.rarity === 'rare' && 'bg-[oklch(0.6_0.2_270)] text-foreground',
        item.rarity === 'uncommon' && 'bg-[oklch(0.65_0.15_200)] text-[oklch(0.12_0.01_260)]',
        item.rarity === 'common' && 'bg-[oklch(0.6_0_0)] text-foreground',
      )}>
        {t(item.rarity)}
      </div>
    </div>
  );
}
