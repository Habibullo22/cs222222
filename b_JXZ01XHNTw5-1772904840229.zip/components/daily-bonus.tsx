'use client';

import { useState, useEffect } from 'react';
import { Gift, Clock, Check, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useGameStore } from '@/lib/store';
import { getTranslation } from '@/lib/i18n';
import { cn } from '@/lib/utils';

export function DailyBonus() {
  const { user, locale, claimDailyBonus } = useGameStore();
  const t = (key: Parameters<typeof getTranslation>[1]) => getTranslation(locale, key);
  
  const [canClaim, setCanClaim] = useState(false);
  const [timeLeft, setTimeLeft] = useState('');
  const [isAnimating, setIsAnimating] = useState(false);

  useEffect(() => {
    const checkBonus = () => {
      if (!user) return;
      
      const now = Date.now();
      const lastBonus = user.lastDailyBonus || 0;
      const oneDayMs = 24 * 60 * 60 * 1000;
      const timeSinceBonus = now - lastBonus;
      
      if (timeSinceBonus >= oneDayMs) {
        setCanClaim(true);
        setTimeLeft('');
      } else {
        setCanClaim(false);
        const remaining = oneDayMs - timeSinceBonus;
        const hours = Math.floor(remaining / (60 * 60 * 1000));
        const minutes = Math.floor((remaining % (60 * 60 * 1000)) / (60 * 1000));
        setTimeLeft(`${hours}h ${minutes}m`);
      }
    };

    checkBonus();
    const interval = setInterval(checkBonus, 60000);
    return () => clearInterval(interval);
  }, [user]);

  const handleClaim = () => {
    if (!canClaim) return;
    
    setIsAnimating(true);
    const success = claimDailyBonus();
    
    if (success) {
      setTimeout(() => {
        setIsAnimating(false);
        setCanClaim(false);
      }, 1000);
    }
  };

  const bonusAmount = 50 + (user?.referralCount || 0) * 10;

  return (
    <div className={cn(
      'relative overflow-hidden rounded-2xl border p-4 transition-all duration-300',
      canClaim 
        ? 'border-primary/50 bg-gradient-to-br from-primary/10 to-primary/5 shadow-[0_0_30px_var(--glow-primary)]' 
        : 'border-border bg-card'
    )}>
      {/* Animated background for claimable state */}
      {canClaim && (
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute -inset-1/2 animate-spin-slow">
            <div className="h-full w-full bg-gradient-conic from-primary/20 via-transparent to-primary/20" />
          </div>
        </div>
      )}

      <div className="relative flex items-center gap-4">
        <div className={cn(
          'flex h-14 w-14 items-center justify-center rounded-xl transition-all duration-300',
          canClaim 
            ? 'bg-primary/20 text-primary' 
            : 'bg-secondary text-muted-foreground'
        )}>
          {canClaim ? (
            <Gift className={cn(
              'h-7 w-7',
              isAnimating && 'animate-bounce'
            )} />
          ) : (
            <Clock className="h-7 w-7" />
          )}
        </div>

        <div className="flex-1">
          <h3 className="text-sm font-semibold text-foreground">{t('dailyBonus')}</h3>
          <p className="text-xs text-muted-foreground">
            {canClaim ? `+${bonusAmount} ${t('coins')}` : timeLeft}
          </p>
        </div>

        <Button
          onClick={handleClaim}
          disabled={!canClaim || isAnimating}
          className={cn(
            'relative min-w-[80px] transition-all duration-300',
            canClaim && 'bg-primary hover:bg-primary/90 shadow-[0_0_15px_var(--glow-primary)]'
          )}
          size="sm"
        >
          {isAnimating ? (
            <Check className="h-4 w-4 animate-scale-in" />
          ) : canClaim ? (
            <>
              <Sparkles className="mr-1.5 h-3.5 w-3.5" />
              {t('claim')}
            </>
          ) : (
            t('claimed')
          )}
        </Button>
      </div>
    </div>
  );
}
