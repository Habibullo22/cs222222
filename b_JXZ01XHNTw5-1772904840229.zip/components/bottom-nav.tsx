'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Home, Box, ArrowUpCircle, Backpack, Store } from 'lucide-react';
import { useGameStore } from '@/lib/store';
import { getTranslation } from '@/lib/i18n';
import { cn } from '@/lib/utils';

const navItems = [
  { href: '/', icon: Home, labelKey: 'home' as const },
  { href: '/cases', icon: Box, labelKey: 'cases' as const },
  { href: '/upgrade', icon: ArrowUpCircle, labelKey: 'upgrade' as const },
  { href: '/inventory', icon: Backpack, labelKey: 'inventory' as const },
  { href: '/market', icon: Store, labelKey: 'market' as const },
];

export function BottomNav() {
  const pathname = usePathname();
  const locale = useGameStore((state) => state.locale);

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 border-t border-border bg-card/95 backdrop-blur-lg">
      <div className="mx-auto flex max-w-lg items-center justify-around">
        {navItems.map((item) => {
          const isActive = pathname === item.href;
          const Icon = item.icon;
          
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                'flex flex-1 flex-col items-center gap-1 py-3 transition-all duration-200',
                isActive 
                  ? 'text-primary' 
                  : 'text-muted-foreground hover:text-foreground'
              )}
            >
              <div className={cn(
                'relative rounded-xl p-2 transition-all duration-200',
                isActive && 'bg-primary/10'
              )}>
                <Icon className={cn(
                  'h-5 w-5 transition-all duration-200',
                  isActive && 'drop-shadow-[0_0_8px_var(--glow-primary)]'
                )} />
                {isActive && (
                  <span className="absolute -bottom-1 left-1/2 h-1 w-1 -translate-x-1/2 rounded-full bg-primary" />
                )}
              </div>
              <span className="text-[10px] font-medium">
                {getTranslation(locale, item.labelKey)}
              </span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
