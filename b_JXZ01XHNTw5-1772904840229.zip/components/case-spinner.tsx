'use client';

import { useState, useEffect, useRef } from 'react';
import { Coins, Volume2, VolumeX } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ItemCard } from '@/components/item-card';
import { useGameStore } from '@/lib/store';
import { getTranslation } from '@/lib/i18n';
import { cn } from '@/lib/utils';
import type { Item, Case } from '@/lib/store';

interface CaseSpinnerProps {
  caseData: Case;
  onComplete?: () => void;
}

export function CaseSpinner({ caseData, onComplete }: CaseSpinnerProps) {
  const { user, locale, openCase } = useGameStore();
  const t = (key: Parameters<typeof getTranslation>[1]) => getTranslation(locale, key);
  
  const [isSpinning, setIsSpinning] = useState(false);
  const [wonItem, setWonItem] = useState<Item | null>(null);
  const [spinItems, setSpinItems] = useState<Item[]>([]);
  const [offset, setOffset] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);

  const canAfford = (user?.balance || 0) >= caseData.price;

  // Generate spin items with the won item at a specific position
  const generateSpinItems = (winner: Item) => {
    const items: Item[] = [];
    const totalItems = 60;
    const winnerPosition = 52; // Position where winner lands

    for (let i = 0; i < totalItems; i++) {
      if (i === winnerPosition) {
        items.push(winner);
      } else {
        const randomItem = caseData.items[Math.floor(Math.random() * caseData.items.length)];
        items.push(randomItem);
      }
    }

    return { items, winnerPosition };
  };

  const handleOpen = () => {
    if (!canAfford || isSpinning) return;

    const result = openCase(caseData.id);
    if (!result) return;

    setIsSpinning(true);
    setWonItem(null);

    const { items, winnerPosition } = generateSpinItems(result);
    setSpinItems(items);
    setOffset(0);

    // Start animation
    requestAnimationFrame(() => {
      const itemWidth = 136; // 128px width + 8px gap
      const targetOffset = winnerPosition * itemWidth - (containerRef.current?.clientWidth || 300) / 2 + itemWidth / 2;
      setOffset(targetOffset);
    });

    // Show result after animation
    setTimeout(() => {
      setIsSpinning(false);
      setWonItem(result);
    }, 5000);
  };

  const handleOpenAgain = () => {
    setWonItem(null);
    setSpinItems([]);
    setOffset(0);
  };

  return (
    <div className="flex flex-col gap-6">
      {/* Spinner container */}
      <div className="relative overflow-hidden rounded-2xl border border-border bg-card">
        {/* Gradient overlays */}
        <div className="pointer-events-none absolute left-0 top-0 bottom-0 z-10 w-20 bg-gradient-to-r from-card to-transparent" />
        <div className="pointer-events-none absolute right-0 top-0 bottom-0 z-10 w-20 bg-gradient-to-l from-card to-transparent" />
        
        {/* Center indicator */}
        <div className="pointer-events-none absolute left-1/2 top-0 bottom-0 z-20 w-0.5 -translate-x-1/2 bg-primary shadow-[0_0_20px_var(--glow-primary)]" />
        <div className="pointer-events-none absolute left-1/2 top-0 z-20 -translate-x-1/2 border-8 border-transparent border-t-primary" />

        {/* Spinner track */}
        <div
          ref={containerRef}
          className="relative h-44 overflow-hidden"
        >
          <div
            className={cn(
              'absolute top-1/2 flex -translate-y-1/2 gap-2 px-[50%]',
              isSpinning && 'transition-transform duration-[5000ms] ease-out'
            )}
            style={{ transform: `translateY(-50%) translateX(-${offset}px)` }}
          >
            {spinItems.length > 0 ? (
              spinItems.map((item, index) => (
                <ItemCard
                  key={index}
                  item={item}
                  size="md"
                  showPrice={false}
                />
              ))
            ) : (
              // Placeholder items
              caseData.items.slice(0, 8).map((item, index) => (
                <ItemCard
                  key={index}
                  item={item}
                  size="md"
                  showPrice={false}
                />
              ))
            )}
          </div>
        </div>
      </div>

      {/* Won item display */}
      {wonItem && (
        <div className="animate-fade-in flex flex-col items-center gap-4 rounded-2xl border border-primary/50 bg-gradient-to-b from-primary/10 to-transparent p-6 shadow-[0_0_40px_var(--glow-primary)]">
          <h3 className="text-lg font-bold text-primary">{t('youWon')}</h3>
          <ItemCard item={wonItem} size="lg" />
          <div className="flex items-center gap-1 text-accent">
            <Coins className="h-5 w-5" />
            <span className="text-xl font-bold">{wonItem.price}</span>
          </div>
        </div>
      )}

      {/* Action buttons */}
      <div className="flex gap-3">
        {wonItem ? (
          <>
            <Button
              onClick={handleOpenAgain}
              disabled={!canAfford}
              className="flex-1 h-14 text-base font-semibold bg-primary hover:bg-primary/90 shadow-[0_0_20px_var(--glow-primary)]"
            >
              <Coins className="mr-2 h-5 w-5" />
              {t('openAgain')} ({caseData.price})
            </Button>
          </>
        ) : (
          <Button
            onClick={handleOpen}
            disabled={!canAfford || isSpinning}
            className={cn(
              'flex-1 h-14 text-base font-semibold transition-all duration-300',
              canAfford && !isSpinning && 'bg-primary hover:bg-primary/90 shadow-[0_0_20px_var(--glow-primary)]'
            )}
          >
            {isSpinning ? (
              <span className="animate-pulse">{t('opening')}</span>
            ) : (
              <>
                <Coins className="mr-2 h-5 w-5" />
                {t('openCase')} ({caseData.price})
              </>
            )}
          </Button>
        )}
      </div>

      {/* Possible items */}
      <div className="rounded-2xl border border-border bg-card p-4">
        <h3 className="mb-4 text-sm font-semibold text-foreground">{t('possibleWins')}</h3>
        <div className="grid grid-cols-4 gap-2">
          {caseData.items.map((item) => (
            <ItemCard
              key={item.id}
              item={item}
              size="sm"
            />
          ))}
        </div>
      </div>
    </div>
  );
}
