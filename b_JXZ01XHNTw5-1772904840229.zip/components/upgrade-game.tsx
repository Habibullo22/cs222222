'use client';

import { useState, useEffect } from 'react';
import { ArrowRight, Zap, Check, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { ItemCard } from '@/components/item-card';
import { useGameStore } from '@/lib/store';
import { getTranslation } from '@/lib/i18n';
import { cn } from '@/lib/utils';
import type { InventoryItem, Item } from '@/lib/store';

export function UpgradeGame() {
  const { user, locale, inventory, cases, removeFromInventory, addToInventory } = useGameStore();
  const t = (key: Parameters<typeof getTranslation>[1]) => getTranslation(locale, key);
  
  const [selectedItem, setSelectedItem] = useState<InventoryItem | null>(null);
  const [targetItem, setTargetItem] = useState<Item | null>(null);
  const [isUpgrading, setIsUpgrading] = useState(false);
  const [result, setResult] = useState<'win' | 'lose' | null>(null);
  const [spinAngle, setSpinAngle] = useState(0);

  // Get all possible target items (more valuable than selected)
  const possibleTargets = selectedItem
    ? cases.flatMap(c => c.items).filter(item => item.price > selectedItem.price)
    : [];

  // Calculate success chance
  const successChance = selectedItem && targetItem
    ? Math.min(95, Math.max(5, Math.floor((selectedItem.price / targetItem.price) * 100)))
    : 0;

  const handleUpgrade = () => {
    if (!selectedItem || !targetItem || isUpgrading) return;

    setIsUpgrading(true);
    setResult(null);

    // Spin animation
    const targetAngle = 1800 + Math.random() * 360; // At least 5 full rotations
    setSpinAngle(targetAngle);

    // Determine result
    const success = Math.random() * 100 < successChance;

    setTimeout(() => {
      setIsUpgrading(false);
      
      if (success) {
        setResult('win');
        removeFromInventory(selectedItem.id);
        addToInventory(targetItem);
      } else {
        setResult('lose');
        removeFromInventory(selectedItem.id);
      }
    }, 3000);
  };

  const handleReset = () => {
    setSelectedItem(null);
    setTargetItem(null);
    setResult(null);
    setSpinAngle(0);
  };

  return (
    <div className="flex flex-col gap-6">
      {/* Upgrade area */}
      <div className="relative rounded-2xl border border-border bg-card p-6">
        <div className="flex items-center justify-center gap-4">
          {/* Source item */}
          <div className="flex flex-col items-center gap-2">
            <p className="text-xs text-muted-foreground">{t('selectItem')}</p>
            {selectedItem ? (
              <ItemCard
                item={selectedItem}
                size="lg"
                onClick={() => !isUpgrading && setSelectedItem(null)}
              />
            ) : (
              <div className="flex h-40 w-40 items-center justify-center rounded-xl border-2 border-dashed border-border bg-secondary/30">
                <span className="text-sm text-muted-foreground">{t('selectItem')}</span>
              </div>
            )}
          </div>

          {/* Arrow and spinner */}
          <div className="flex flex-col items-center gap-2">
            <div className={cn(
              'relative flex h-20 w-20 items-center justify-center rounded-full border-4 border-primary/30 transition-all duration-300',
              isUpgrading && 'border-primary shadow-[0_0_30px_var(--glow-primary)]'
            )}>
              {/* Spinning indicator */}
              <div
                className="absolute inset-1 rounded-full bg-gradient-to-r from-primary to-primary/50"
                style={{
                  transform: `rotate(${spinAngle}deg)`,
                  transition: isUpgrading ? 'transform 3s cubic-bezier(0.25, 0.1, 0.25, 1)' : 'none',
                  clipPath: 'polygon(50% 50%, 50% 0, 100% 0, 100% 50%)',
                }}
              />
              
              {/* Center icon */}
              <div className="relative z-10 flex h-10 w-10 items-center justify-center rounded-full bg-card">
                {result === 'win' ? (
                  <Check className="h-6 w-6 text-primary animate-scale-in" />
                ) : result === 'lose' ? (
                  <X className="h-6 w-6 text-destructive animate-scale-in" />
                ) : (
                  <Zap className={cn(
                    'h-6 w-6 text-primary',
                    isUpgrading && 'animate-pulse'
                  )} />
                )}
              </div>
            </div>
            
            {/* Success chance */}
            <div className={cn(
              'rounded-full px-3 py-1 text-sm font-bold',
              successChance >= 50 ? 'bg-primary/20 text-primary' : 'bg-destructive/20 text-destructive'
            )}>
              {successChance}%
            </div>
          </div>

          {/* Target item */}
          <div className="flex flex-col items-center gap-2">
            <p className="text-xs text-muted-foreground">{t('targetItem')}</p>
            {targetItem ? (
              <ItemCard
                item={targetItem}
                size="lg"
                onClick={() => !isUpgrading && setTargetItem(null)}
              />
            ) : (
              <div className="flex h-40 w-40 items-center justify-center rounded-xl border-2 border-dashed border-border bg-secondary/30">
                <span className="text-sm text-muted-foreground">{t('targetItem')}</span>
              </div>
            )}
          </div>
        </div>

        {/* Result message */}
        {result && (
          <div className={cn(
            'mt-6 rounded-xl p-4 text-center text-lg font-bold',
            result === 'win' 
              ? 'bg-primary/20 text-primary shadow-[0_0_20px_var(--glow-primary)]' 
              : 'bg-destructive/20 text-destructive'
          )}>
            {result === 'win' ? t('upgradeWin') : t('upgradeLose')}
          </div>
        )}
      </div>

      {/* Action button */}
      {result ? (
        <Button
          onClick={handleReset}
          className="h-14 text-base font-semibold"
        >
          {t('upgrade')} Again
        </Button>
      ) : (
        <Button
          onClick={handleUpgrade}
          disabled={!selectedItem || !targetItem || isUpgrading}
          className={cn(
            'h-14 text-base font-semibold transition-all duration-300',
            selectedItem && targetItem && !isUpgrading && 'bg-primary hover:bg-primary/90 shadow-[0_0_20px_var(--glow-primary)]'
          )}
        >
          {isUpgrading ? (
            <span className="animate-pulse">{t('loading')}</span>
          ) : (
            <>
              <Zap className="mr-2 h-5 w-5" />
              {t('startUpgrade')}
            </>
          )}
        </Button>
      )}

      {/* Your inventory for selection */}
      {!selectedItem && inventory.length > 0 && (
        <div className="rounded-2xl border border-border bg-card p-4">
          <h3 className="mb-4 text-sm font-semibold text-foreground">{t('myInventory')}</h3>
          <div className="grid grid-cols-3 gap-2">
            {inventory.map((item) => (
              <ItemCard
                key={item.id}
                item={item}
                size="sm"
                onClick={() => setSelectedItem(item)}
              />
            ))}
          </div>
        </div>
      )}

      {/* Target selection */}
      {selectedItem && !targetItem && possibleTargets.length > 0 && (
        <div className="rounded-2xl border border-border bg-card p-4">
          <h3 className="mb-4 text-sm font-semibold text-foreground">{t('targetItem')}</h3>
          <div className="grid grid-cols-3 gap-2">
            {possibleTargets.slice(0, 9).map((item, index) => (
              <ItemCard
                key={`${item.id}-${index}`}
                item={item}
                size="sm"
                onClick={() => setTargetItem(item)}
              />
            ))}
          </div>
        </div>
      )}

      {/* Empty state */}
      {inventory.length === 0 && (
        <div className="rounded-2xl border border-border bg-card p-8 text-center">
          <p className="text-muted-foreground">{t('emptyInventory')}</p>
        </div>
      )}
    </div>
  );
}
