'use client';

import Link from 'next/link';
import { Box, Coins } from 'lucide-react';
import { cn } from '@/lib/utils';
import type { Case } from '@/lib/store';
import { useGameStore } from '@/lib/store';
import { getTranslation } from '@/lib/i18n';

interface CaseCardProps {
  caseData: Case;
  className?: string;
}

export function CaseCard({ caseData, className }: CaseCardProps) {
  const { user, locale } = useGameStore();
  const t = (key: Parameters<typeof getTranslation>[1]) => getTranslation(locale, key);
  const canAfford = (user?.balance || 0) >= caseData.price;

  // Get best rarity in case
  const bestRarity = caseData.items.reduce((best, item) => {
    const order = ['common', 'uncommon', 'rare', 'epic', 'legendary'];
    return order.indexOf(item.rarity) > order.indexOf(best) ? item.rarity : best;
  }, 'common' as string);

  const glowClass = {
    legendary: 'hover:shadow-[0_0_40px_oklch(0.75_0.2_50/0.4)]',
    epic: 'hover:shadow-[0_0_30px_oklch(0.65_0.25_320/0.3)]',
    rare: 'hover:shadow-[0_0_25px_oklch(0.6_0.2_270/0.3)]',
    uncommon: 'hover:shadow-[0_0_20px_oklch(0.65_0.15_200/0.3)]',
    common: '',
  }[bestRarity];

  return (
    <Link
      href={`/cases/${caseData.id}`}
      className={cn(
        'group relative flex flex-col overflow-hidden rounded-2xl border border-border bg-card transition-all duration-300 hover:scale-[1.02] hover:border-primary/50',
        glowClass,
        className
      )}
    >
      {/* Case image area */}
      <div className="relative flex h-36 items-center justify-center bg-gradient-to-b from-secondary/50 to-transparent p-4">
        <div className="relative flex h-20 w-20 items-center justify-center rounded-xl bg-primary/10 transition-transform duration-300 group-hover:scale-110 group-hover:rotate-3">
          <Box className="h-12 w-12 text-primary drop-shadow-[0_0_15px_var(--glow-primary)]" />
        </div>
        
        {/* Floating items preview */}
        <div className="absolute bottom-2 left-1/2 flex -translate-x-1/2 gap-1">
          {caseData.items.slice(0, 4).map((item, i) => (
            <div
              key={i}
              className={cn(
                'h-6 w-6 rounded-md border flex items-center justify-center text-[10px]',
                item.rarity === 'legendary' && 'border-[oklch(0.75_0.2_50)] bg-[oklch(0.75_0.2_50/0.2)]',
                item.rarity === 'epic' && 'border-[oklch(0.65_0.25_320)] bg-[oklch(0.65_0.25_320/0.2)]',
                item.rarity === 'rare' && 'border-[oklch(0.6_0.2_270)] bg-[oklch(0.6_0.2_270/0.2)]',
                item.rarity === 'uncommon' && 'border-[oklch(0.65_0.15_200)] bg-[oklch(0.65_0.15_200/0.2)]',
                item.rarity === 'common' && 'border-muted-foreground/30 bg-muted/50',
              )}
            >
              🔫
            </div>
          ))}
        </div>
      </div>

      {/* Case info */}
      <div className="flex flex-col gap-2 p-4">
        <h3 className="text-base font-semibold text-foreground">{caseData.name}</h3>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <Coins className="h-4 w-4 text-accent" />
            <span className={cn(
              'text-sm font-bold',
              canAfford ? 'text-accent' : 'text-destructive'
            )}>
              {caseData.price}
            </span>
          </div>
          
          <span className="text-xs text-muted-foreground">
            {caseData.items.length} {t('possibleWins').toLowerCase()}
          </span>
        </div>

        {/* Open button */}
        <div className={cn(
          'mt-2 rounded-lg py-2 text-center text-sm font-semibold transition-all duration-300',
          canAfford 
            ? 'bg-primary text-primary-foreground group-hover:shadow-[0_0_20px_var(--glow-primary)]' 
            : 'bg-secondary text-muted-foreground'
        )}>
          {t('openCase')}
        </div>
      </div>
    </Link>
  );
}
